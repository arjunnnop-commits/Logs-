package com.fairy.logs

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusTv: TextView
    private lateinit var countTv: TextView
    private lateinit var liveTv: TextView
    private lateinit var scroll: ScrollView
    private lateinit var mainBtn: Button
    private lateinit var markEt: EditText
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 800) }
    }
    private val MP = LinearLayout.LayoutParams.MATCH_PARENT
    private val WC = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun glass(fill: Int, radius: Int = 16) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), 0x44FFFFFF)
    }

    private fun mkBtn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); background = glass(0x22FFFFFF)
        setOnClickListener { onClick() }
    }

    private fun lp(top: Int = 10) = LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(16), dp(36), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Fairy Logs"; textSize = 28f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        statusTv = TextView(this).apply { textSize = 13f; setTextColor(Color.LTGRAY) }
        root.addView(statusTv, lp(4))
        countTv = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE) }
        root.addView(countTv, lp(4))

        mainBtn = mkBtn("START") { onMain() }
        mainBtn.textSize = 18f
        root.addView(mainBtn, lp(12))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        markEt = EditText(this).apply {
            hint = "Test ka naam (e.g. WiFi on/off)"; setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE); setSingleLine(true); textSize = 14f
        }
        row.addView(markEt, LinearLayout.LayoutParams(0, WC, 1f))
        row.addView(mkBtn("MARK") { doMark(markEt.text.toString()) })
        root.addView(row, lp(8))

        val presets = listOf("WiFi", "Bluetooth", "Camera", "Calling", "SIM/Data", "Audio", "Fingerprint/FOD", "Display", "Sensors", "Sleep")
        val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in presets) {
            pr.addView(mkBtn(p) { markEt.setText("$p test"); doMark("$p test") }.apply { textSize = 12f },
                LinearLayout.LayoutParams(WC, dp(42)).apply { rightMargin = dp(6) })
        }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(pr) }, lp(4))

        liveTv = TextView(this).apply {
            textSize = 11f; setTextColor(Color.LTGRAY); typeface = Typeface.MONOSPACE; setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        scroll = ScrollView(this).apply { background = glass(0x11FFFFFF); addView(liveTv) }
        root.addView(scroll, LinearLayout.LayoutParams(MP, 0, 1f).apply { topMargin = dp(10) })

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bottom.addView(mkBtn("Copy AI summary") { copySummary() }, LinearLayout.LayoutParams(0, WC, 1f))
        bottom.addView(mkBtn("Noise filter") { noiseDialog() }, LinearLayout.LayoutParams(0, WC, 1f))
        root.addView(bottom, lp(8))
        setContentView(root)
    }

    private fun onMain() {
        val s = Collector.snap()
        when {
            s.saving -> {}
            s.running -> startService(Intent(this, LogService::class.java).setAction("STOP"))
            s.active -> {}
            else -> startForegroundService(Intent(this, LogService::class.java))
        }
    }

    private fun doMark(label: String) {
        if (!Collector.snap().running) { Toast.makeText(this, "Pehle START dabao", Toast.LENGTH_SHORT).show(); return }
        Collector.mark(label)
    }

    private fun copySummary() {
        val t = Collector.aiSummary
        if (t.isEmpty()) { Toast.makeText(this, "Pehle STOP karke report banao", Toast.LENGTH_SHORT).show(); return }
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ai", t))
        Toast.makeText(this, "AI summary copy ho gaya", Toast.LENGTH_SHORT).show()
    }

    private fun noiseDialog() {
        val prefs = getSharedPreferences("fl", 0)
        val et = EditText(this).apply {
            setText(prefs.getString("noise", "")); hint = "Ek line = ek ignore text (spam lines)"
            minLines = 6; gravity = Gravity.TOP
        }
        AlertDialog.Builder(this).setTitle("Noise filter").setView(et)
            .setPositiveButton("Save") { _, _ -> prefs.edit().putString("noise", et.text.toString()).apply() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun refresh() {
        val s = Collector.snap()
        statusTv.text = s.status
        countTv.text = "Lines ${s.total}  |  Kept ${s.kept}  |  Unique ${s.unique}\nTest: ${s.mark}"
        mainBtn.text = when {
            s.saving -> "Saving..."
            s.running -> "STOP & SAVE"
            s.active -> "Starting..."
            else -> "START"
        }
        mainBtn.isEnabled = !(s.saving || (s.active && !s.running))
        val t = s.live.joinToString("\n")
        if (t != liveTv.text.toString()) {
            liveTv.text = t
            if (s.running) scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
        }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
