package com.fairy.logs

import android.content.Context
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TreeSet
import kotlin.concurrent.thread

object Root {
    fun run(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) { "" }

    fun sh(cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) { "" }

    fun hasRoot() = run("id").contains("uid=0")
}

object Comp {
    private fun r(p: String) = Regex(p, RegexOption.IGNORE_CASE)
    private val rules = listOf(
        "FOD" to r("sofod|unifiedfodbridge|fodbridge|udfps|fingerprint|biometric|goodix|fpc_|(?<![a-z])fod(?![a-z])"),
        "CAMERA" to r("camera|camx|mtkcam|flashlight|(?<![a-z])cam(?![a-z])"),
        "WIFI" to r("wifi|wlan|wpa_supplicant|wificond|hostapd|cnss|supplicant|(?<![a-z])p2p"),
        "BLUETOOTH" to r("bluetooth|(?<![a-z])bt(?![a-z])|btif|bluedroid|a2dp|(?<![a-z])hfp"),
        "AUDIO" to r("audio|alsa|speaker|microphone|(?<![a-z])aud(?![a-z])"),
        "RIL" to r("(?<![a-z])(ril|rild|ims|sim)(?![a-z])|radio|telephony|telecom|modem|volte|carrierconfig"),
        "SENSORS" to r("sensor|accelerometer|gyro|proximity|(?<![a-z])sns"),
        "GPS" to r("(?<![a-z])(gps|gnss)(?![a-z])|location"),
        "NFC" to r("(?<![a-z])nfc|nxp"),
        "VIBRATOR" to r("vibrator|haptic|awinic|(?<![a-z])lra(?![a-z])"),
        "USB" to r("(?<![a-z])usb|typec|(?<![a-z])mtp(?![a-z])"),
        "SECURITY" to r("widevine|mediadrm|keymaster|keymint|gatekeeper|keystore|weaver|strongbox|(?<![a-z])drm(?![a-z])"),
        "DISPLAY" to r("surfaceflinger|hwcomposer|composer|(?<![a-z])hwc|gralloc|backlight|display|panel|(?<![a-z])lcd|refresh ?rate"),
        "MEDIA" to r("mediacodec|(?<![a-z])omx|codec2|mediaserver|mediaplayer|stagefright|mediaextractor"),
        "POWER" to r("powermanager|suspend|wakelock|doze|deviceidle|healthd|battery|charger|thermal|deep ?sleep|wakeup|pmic"),
        "SYSTEM" to r("system_server|zygote|activitymanager|windowmanager|packagemanager|androidruntime"),
        "INIT" to r("(?<![a-z])init(?![a-z])|servicemanager|linker|apexd|vold|ueventd|selinux"),
        "KERNEL" to r("kernel|(?<![a-z])dmesg")
    )

    fun classify(tag: String, msg: String, msgFirst: Boolean): String {
        val a = if (msgFirst) msg else tag
        val b = if (msgFirst) tag else msg
        for ((n, re) in rules) if (re.containsMatchIn(a)) return n
        for ((n, re) in rules) if (re.containsMatchIn(b)) return n
        return "OTHER"
    }
}

class Group(
    val key: String, val comp: String, val level: Char, val tag: String,
    val msg: String, val line: String, val time: String, val crash: Boolean
) {
    var count = 0
    var last = time
    val before = ArrayList<String>()
    val after = ArrayList<String>()
    val markCounts = LinkedHashMap<String, Int>()
}

class Avc(val scon: String, val tcon: String, val cls: String, val comp: String) {
    val perms = TreeSet<String>()
    var count = 0
    val marks = LinkedHashSet<String>()
    fun rule() = "allow $scon $tcon:$cls { ${perms.joinToString(" ")} };"
}

class KLine(val line: String) { var count = 0 }

class Snap(
    val status: String, val total: Long, val kept: Long, val unique: Int, val mark: String,
    val live: List<String>, val running: Boolean, val active: Boolean, val saving: Boolean
)

object Collector {
    @Volatile var active = false
    @Volatile var running = false
    @Volatile var saving = false
    @Volatile var status = "Ready. START dabao."
    @Volatile var aiSummary = ""

    private val lock = Any()
    private val groups = LinkedHashMap<String, Group>()
    private val avcs = LinkedHashMap<String, Avc>()
    private val kernel = LinkedHashMap<String, KLine>()
    private val marks = ArrayList<String>()
    private val markNames = LinkedHashSet<String>()
    private var currentMark = "(start)"
    private var totalLines = 0L
    private var keptLines = 0L
    private val ring = java.util.ArrayDeque<String>()
    private val pending = ArrayList<Group>()
    private val live = java.util.ArrayDeque<String>()
    private val sticky = HashMap<String, String?>()
    private var raw: BufferedWriter? = null
    private var rawBytes = 0L
    private var noise: List<String> = emptyList()
    private var readerThread: Thread? = null
    private var startMs = 0L
    private lateinit var dir: File

    private val lineRe = Regex("""^(\d\d-\d\d \d\d:\d\d:\d\d\.\d+)\s+(\d+)\s+(\d+)\s+([VDIWEF])\s+(.*?)\s*:\s(.*)$""")
    private val crashRe = Regex("FATAL EXCEPTION|ANR in |Fatal signal|has died|Native crash|am_crash|am_anr|SIGSEGV|SIGABRT|\\*\\*\\* \\*\\*\\*|Force finishing|has crashed|Abort message")
    private val warnRe = Regex("fail|denied|died|not found|missing|timeout|timed out|cannot|can't|unable|invalid|error|exception|no such|unsupported|crash", RegexOption.IGNORE_CASE)
    private val avcRe = Regex("""avc:\s+denied\s+\{\s*([^}]*?)\s*\}.*?scontext=u:r:(\w+):s0\S*\s+tcontext=u:\w+:(\w+):s0\S*\s+tclass=(\w+)""")
    private val kerRe = Regex("fail|error|panic|oops|timeout|timed out|unable to|cannot|can't|firmware|BUG:|WARNING|denied", RegexOption.IGNORE_CASE)
    private val hexRe = Regex("0x[0-9a-fA-F]+")
    private val numRe = Regex("\\d+")

    fun snap(): Snap = synchronized(lock) {
        Snap(status, totalLines, keptLines, groups.size + avcs.size, currentMark, ArrayList(live), running, active, saving)
    }

    fun mark(label: String) = synchronized(lock) {
        val l = label.trim().ifEmpty { "mark${marks.size + 1}" }
        currentMark = l
        markNames.add(l)
        marks.add(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + l)
        addLive("---------- MARK: $l ----------")
    }

    private fun addLive(s: String) {
        live.addLast(s)
        if (live.size > 80) live.removeFirst()
    }

    fun start(ctx: Context, onFail: () -> Unit) {
        if (active || saving) return
        active = true
        val prefs = ctx.getSharedPreferences("fl", 0)
        synchronized(lock) {
            groups.clear(); avcs.clear(); kernel.clear(); marks.clear(); markNames.clear()
            ring.clear(); pending.clear(); live.clear(); sticky.clear()
            currentMark = "(start)"; markNames.add(currentMark)
            totalLines = 0; keptLines = 0; rawBytes = 0
            noise = (prefs.getString("noise", "") ?: "").lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            status = "Root check ho raha hai..."
        }
        thread {
            if (!Root.hasRoot()) {
                status = "Root nahi mila! Magisk/KernelSU me Fairy Logs ko root do."
                active = false
                onFail()
                return@thread
            }
            startMs = System.currentTimeMillis()
            val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            dir = File(ctx.filesDir, "session_$ts").apply { mkdirs() }
            raw = BufferedWriter(FileWriter(File(dir, "raw.log")))
            Root.run("touch /data/local/tmp/fairylogs_start; logcat -b all -c")
            running = true
            status = "Collecting... ab bug trigger karo"
            readerThread = thread {
                try {
                    val p = ProcessBuilder("su", "-c", "logcat -b all -v threadtime").redirectErrorStream(true).start()
                    p.inputStream.bufferedReader().use { r ->
                        while (true) {
                            val line = r.readLine() ?: break
                            handle(line)
                        }
                    }
                } catch (e: Exception) {
                    status = "Logcat error: ${e.message}"
                }
            }
        }
    }

    private fun handle(line: String) {
        synchronized(lock) {
            totalLines++
            if (rawBytes < 60_000_000) {
                try { raw?.write(line); raw?.write("\n"); rawBytes += line.length + 1 } catch (_: Exception) {}
            }
            val iter = pending.iterator()
            while (iter.hasNext()) {
                val g = iter.next()
                g.after.add(line.take(260))
                if (g.after.size >= 10) iter.remove()
            }
            val m = lineRe.find(line)
            if (m != null) process(line, m)
            ring.addLast(line.take(260))
            if (ring.size > 10) ring.removeFirst()
        }
    }

    private fun process(line: String, m: MatchResult) {
        val time = m.groupValues[1]
        val level = m.groupValues[4][0]
        val tag = m.groupValues[5].trim()
        val msg = m.groupValues[6]
        val low = (tag + " " + msg).lowercase()
        if (low.contains("com.fairy.logs") || low.contains("fairylogs")) return
        for (n in noise) if (low.contains(n)) return

        val avc = if (msg.contains("avc:") && msg.contains("denied")) avcRe.find(msg) else null
        val crash = crashRe.containsMatchIn(msg)
        val keep = avc != null || crash || level == 'E' || level == 'F' ||
            (level == 'W' && warnRe.containsMatchIn(msg))
        if (!keep) return
        keptLines++

        if (avc != null) {
            val a = addAvc(avc, true)
            addLive("[SELINUX/${a.comp}] ${a.scon} -> ${a.tcon}:${a.cls}")
            return
        }

        val comp: String
        if (tag == "AndroidRuntime" || tag == "DEBUG") {
            if (msg.contains("FATAL EXCEPTION") || msg.contains("*** ***")) sticky[tag] = null
            else if (msg.contains("Process:") || msg.contains(">>>")) sticky[tag] = Comp.classify(tag, msg, true)
            comp = sticky[tag] ?: Comp.classify(tag, msg, true)
        } else {
            comp = Comp.classify(tag, msg, crash)
        }

        val norm = msg.replace(hexRe, "0x#").replace(numRe, "#").take(160)
        val key = "$comp|$level|$tag|$norm"
        var g = groups[key]
        if (g == null) {
            if (groups.size >= 5000) return
            g = Group(key, comp, level, tag, msg.take(300), line.take(300), time, crash)
            g.before.addAll(ring)
            groups[key] = g
            pending.add(g)
        }
        g.count++
        g.last = time
        g.markCounts[currentMark] = (g.markCounts[currentMark] ?: 0) + 1
        addLive("[$comp] $level $tag: ${msg.take(140)}")
    }

    private fun addAvc(m: MatchResult, count: Boolean): Avc {
        val perms = m.groupValues[1].trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val s = m.groupValues[2]
        val t = m.groupValues[3]
        val c = m.groupValues[4]
        val a = avcs.getOrPut("$s|$t|$c") { Avc(s, t, c, Comp.classify("$s $t", "", false)) }
        a.perms.addAll(perms)
        if (count) a.count++
        a.marks.add(currentMark)
        return a
    }

    fun stop(ctx: Context, done: () -> Unit) {
        if (!running) { done(); return }
        running = false
        saving = true
        status = "Report save ho raha hai..."
        thread {
            try {
                Root.run("pkill logcat; killall logcat")
                readerThread?.join(3000)
                synchronized(lock) { try { raw?.flush(); raw?.close() } catch (_: Exception) {} }
                val dm = Root.run("dmesg")
                val device = deviceInfo()
                synchronized(lock) { parseDmesg(dm); writeAll(device) }
                val out = "/sdcard/FairyLogs/${dir.name}"
                Root.run(
                    "mkdir -p /sdcard/FairyLogs && cp -r '${dir.absolutePath}' /sdcard/FairyLogs/ && mkdir -p '$out/crashes'; " +
                        "find /data/tombstones /data/anr -type f -newer /data/local/tmp/fairylogs_start -exec cp {} '$out/crashes/' \\; ; " +
                        "cp /sys/fs/pstore/* '$out/crashes/' 2>/dev/null; chmod -R 777 /sdcard/FairyLogs"
                )
                status = "Saved: $out"
            } catch (e: Exception) {
                status = "Save error: ${e.message}"
            }
            saving = false
            active = false
            done()
        }
    }

    private fun deviceInfo(): String {
        val keys = listOf(
            "ro.product.manufacturer", "ro.product.model", "ro.product.device", "ro.build.display.id",
            "ro.build.fingerprint", "ro.vendor.build.fingerprint", "ro.build.version.release",
            "ro.build.version.sdk", "ro.build.version.security_patch", "ro.board.platform",
            "ro.hardware", "ro.build.type", "ro.boot.verifiedbootstate"
        )
        val sb = StringBuilder()
        for (k in keys) {
            val v = Root.sh("getprop $k").trim()
            if (v.isNotEmpty()) sb.append("$k = $v\n")
        }
        sb.append("selinux = ${Root.sh("getenforce").trim()}\n")
        sb.append("kernel = ${Root.sh("uname -a").trim()}\n")
        return sb.toString()
    }

    private fun parseDmesg(text: String) {
        for (l0 in text.lines()) {
            val l = l0.trim()
            if (l.isEmpty()) continue
            val body = l.replace(Regex("^<\\d+>"), "").replace(Regex("^\\[[^\\]]*\\]\\s*"), "")
            val avc = if (body.contains("avc:") && body.contains("denied")) avcRe.find(body) else null
            if (avc != null) { addAvc(avc, false); continue }
            if (kernel.size < 300 && kerRe.containsMatchIn(body)) {
                val key = body.replace(numRe, "#").take(120)
                kernel.getOrPut(key) { KLine(l.take(240)) }.count++
            }
        }
    }

    private fun prio(g: Group) = (if (g.crash) 1_000_000 else 0) + (if (g.level == 'F') 500_000 else 0) + g.count
    private fun fmt(g: Group) = "x${g.count} ${g.level}/${g.tag}: ${g.msg.take(220)}"

    private fun writeAll(device: String) {
        val sorted = groups.values.sortedByDescending { prio(it) }
        val hits = HashMap<String, Int>()
        val uniq = HashMap<String, Int>()
        for (g in groups.values) {
            hits[g.comp] = (hits[g.comp] ?: 0) + g.count
            uniq[g.comp] = (uniq[g.comp] ?: 0) + 1
        }
        for (a in avcs.values) {
            hits[a.comp] = (hits[a.comp] ?: 0) + a.count
            uniq[a.comp] = (uniq[a.comp] ?: 0) + 1
        }
        val compOrder = hits.entries.sortedByDescending { it.value }.map { it.key }
        val avcSorted = avcs.values.sortedByDescending { it.count }

        val sb = StringBuilder()
        sb.append("===== FAIRY LOGS REPORT =====\n")
        sb.append("Duration: ${(System.currentTimeMillis() - startMs) / 1000}s | lines: $totalLines | kept: $keptLines | unique: ${groups.size}\n\n")
        sb.append("== DEVICE ==\n").append(device).append("\n")

        sb.append("== COMPONENT SUMMARY (unique / hits) ==\n")
        for (c in compOrder) sb.append("  [$c]  ${uniq[c]} unique / ${hits[c]} hits\n")

        sb.append("\n== CRASHES / ANR / FATAL ==\n")
        val crashes = sorted.filter { it.crash }
        if (crashes.isEmpty()) sb.append("  (none)\n")
        for (g in crashes) sb.append("  [${g.comp}] ${fmt(g)}  (first ${g.time})\n")

        sb.append("\n== SELINUX DENIALS (${avcSorted.size}) ==\n")
        for (a in avcSorted) {
            sb.append("  [${a.comp}] x${a.count} ${a.scon} -> ${a.tcon}:${a.cls} { ${a.perms.joinToString(" ")} }\n")
            sb.append("      ${a.rule()}\n")
        }
        sb.append("  NOTE: kuch denials neverallow se block hote hain, wahan type/attribute fix karna padega.\n")

        sb.append("\n== ERRORS BY COMPONENT ==\n")
        for (c in compOrder) {
            val list = sorted.filter { it.comp == c }
            if (list.isEmpty()) continue
            sb.append("\n---- [$c] ----\n")
            for (g in list.take(60)) sb.append("  ${fmt(g)}  [first ${g.time}, test: ${g.markCounts.keys.joinToString(",")}]\n")
        }

        sb.append("\n== BY TEST (marks) ==\n")
        for (name in markNames) {
            val list = sorted.filter { it.markCounts.containsKey(name) }.sortedByDescending { it.markCounts[name] ?: 0 }
            val av = avcSorted.filter { it.marks.contains(name) }
            if (list.isEmpty() && av.isEmpty()) continue
            sb.append("\n-- $name --\n")
            for (g in list.take(40)) sb.append("  x${g.markCounts[name]} [${g.comp}] ${g.level}/${g.tag}: ${g.msg.take(180)}\n")
            for (a in av.take(20)) sb.append("  [SELINUX/${a.comp}] ${a.rule()}\n")
        }

        sb.append("\n== KERNEL (dmesg) ==\n")
        for (k in kernel.values.take(150)) sb.append("  x${k.count} ${k.line}\n")

        sb.append("\n== MARK TIMELINE ==\n")
        for (m in marks) sb.append("  $m\n")
        File(dir, "report.txt").writeText(sb.toString())

        val te = StringBuilder("# Generated by Fairy Logs - review before use\n")
        for (a in avcSorted) te.append(a.rule()).append("\n")
        File(dir, "selinux_rules.te").writeText(te.toString())

        val ai = StringBuilder()
        ai.append("# Android ROM port bug report (Fairy Logs)\n")
        ai.append("Ye ported ROM ke logs hain. Har error ka component, root cause aur fix (prop / sepolicy / blob / HAL / init rc) batao.\n\n")
        ai.append("## DEVICE\n").append(device).append("\n")
        ai.append("## TOP 20 ERRORS (context ke saath)\n")
        var i = 1
        for (g in sorted.take(20)) {
            if (ai.length > 60000) break
            ai.append("\n### ${i++}. [${g.comp}] ${fmt(g)}\n")
            ai.append("test: ${g.markCounts.keys.joinToString(",")}\n")
            for (b in g.before) ai.append("   ").append(b).append("\n")
            ai.append(">>> ").append(g.line).append("\n")
            for (a in g.after) ai.append("   ").append(a).append("\n")
        }
        ai.append("\n## SELINUX (top 15)\n")
        for (a in avcSorted.take(15)) ai.append("[${a.comp}] x${a.count} ${a.rule()}\n")
        ai.append("\n## KERNEL (top 15)\n")
        for (k in kernel.values.sortedByDescending { it.count }.take(15)) ai.append("x${k.count} ${k.line}\n")
        aiSummary = ai.toString()
        File(dir, "ai_summary.txt").writeText(aiSummary)
    }
}
